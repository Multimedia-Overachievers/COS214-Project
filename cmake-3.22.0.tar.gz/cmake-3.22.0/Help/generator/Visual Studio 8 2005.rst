Visual Studio 8 2005
--------------------

Removed.  This once generated Visual Studio 8 2005 project files, but
the generator has been removed since CMake 3.12.  It is still possible to
build with VS 2005 tools using the :generator:`NMake Makefiles` generator.
