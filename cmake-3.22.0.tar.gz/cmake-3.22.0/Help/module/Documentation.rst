.. cmake-module:: ../../Modules/Documentation.cmake
